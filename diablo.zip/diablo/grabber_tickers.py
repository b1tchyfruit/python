import time, json, uuid
import requests, psycopg2
from bfxii import wrapperii

from psycopg2 import extras

# collecting data from tickers


# get all symbols from the existing database
# connect to the DB
conn = psycopg2.connect("dbname=inferno user=innerpartycolt")

# open a cursor
cur = conn.cursor()

# select only pairs
cur.execute("""
	select pair from symbol_details;
	""")

# prepare an empty list
all_symbols = list()

# put all pairs in set to eliminate duplicates
symbols_set = set(cur.fetchall())

# close communication
cur.close()
conn.close()

# iterate over set to extract pairs from tuples
for pair in symbols_set:
	all_symbols.append(pair[0])

# inform
print('\n{}\n'.format(all_symbols))
print('success')

# preparing to pass all pairs to the ticker() function
# put all pairs into a single string
symbols = ','.join(all_symbols)
#print(symbols)

# instantiate Bitfinex class
x = wrapperii.Bitfinex()

# make an API call via function to get data about selected pairs
tickers_raw = x.tickers(symbols)
#print(tickers_raw)


# getting BTC rate
btc_rate = x.ticker('tBTCUSD')[6]
print(btc_rate)

# trimming the data received via API
tickers_parsed = list()
for item in tickers_raw:

	# grab data that matches following criteria
	if True: #item[6] > 0.01 and ((item[8] * item[7] / btc_rate) > 700):
		u = uuid.uuid1()
		t = list()
		t.append(str(u)) # id
		t.append(item[0]) # symbol
		t.append(item[6]) # daily change in percentage
		t.append(item[7]) # last price
		t.append(item[8] * item[7]) # volume; converting volume to USD; volume * last price
		t.append(item[9]) # high
		t.append('now()')
		tickers_parsed.append(tuple(t))


print(tickers_parsed)

# connect to the DB
conn = psycopg2.connect("dbname=inferno user=innerpartycolt")

# open a cursor
cur = conn.cursor()

# select only pairs
#cur.execute("""

#drop table if exists tickers;

#create table tickers (
#	id varchar(36) unique,
#	symbol varchar(10),
#	daily_change_perc decimal,
#	last_price decimal,
#	volume integer,
#	high decimal,
#	last_update timestamp
#);

#""")



# remove data older than 35 minutes
cur.execute("""
	select * from tickers;
	delete from tickers
		where last_update < now() - interval '35 minutes';

	""")


# pass the data
extras.execute_values(cur,
	"insert into tickers (id, symbol, daily_change_perc, last_price, volume, high, last_update) values %s",
	tickers_parsed
	)

# lookup changes
print('\ndata preview')
cur.execute("select * from tickers;")
for record in cur:
	print(record)

# make the changes to the database persistent
conn.commit()

# inform
print('data commit successful')


#??? select * from tickers where volume > 10000000 and daily_change_perc > 0.01 order by last_update DESC, daily_change_perc DESC;


# close communication
cur.close()
conn.close()