import json
import requests

base_url = 'https://api.bitfinex.com/v2/'

public = {
	'tickers' : 'tickers?symbols=',
	'ticker': 'ticker/',
}

class Bitfinex:

	def tickers(self, symbols):
		url = base_url + public['tickers'] + symbols
		response = requests.request('GET', url)

		return json.loads(response.text)


	def ticker(self, symbol):
		url = base_url + public['ticker'] + symbol
		response = requests.request('GET', url)

		return json.loads(response.text)