'SHEBANG'
import time, json, uuid, copy
import requests
from bfxii import wrapperii
from bfxi import wrapperi

# instantiate Bitfinex class
x = wrapperii.Bitfinex()
y = wrapperi.Bitfinex()



	# balance
def check_balance(wallet, symbol):
	balance_total = None
	balance_available = None

	# wallet = deposit, exchange, trading

	for i in y.balances():
		if i['type'] == wallet and i['currency'] == symbol:
			balance_total = float(i['amount'])
			balance_available = float(i['available'])

	return balance_total, balance_available



# list of pairs for triangular arbitrage
all_symbols = ['tIOTETH', 'tIOTUSD', 'tETHUSD']
symbols = ','.join(all_symbols)

# make an API call via function to get data about selected pairs
tickers_raw = x.tickers(symbols)
#for i in tickers_raw:
#	print(i)

# BID > ASK > BID (buy > sell > buy)
round1_bid = float(tickers_raw[0][1]) # eth > iot
round2_ask = float(tickers_raw[1][3]) # iot > usd
round3_bid = float(tickers_raw[2][1]) # usd > eth

round1_inter = None
round2_inter = None
round3_inter = None

# buy IOT for ETH
def round1():
	# minimum order AMOUNT for the first round with a little extra
	round1_amount = 10
	#round1_amount = 6 + (6 * 0.1)

	# check actual price using list index
	round1_ticker = x.ticker(all_symbols[0])[0]
	
	# amount, price, order type, market type, symbols
	round1_result = y.order_new(str(round1_amount), str(round1_ticker), 'buy', 'exchange market', 'ioteth')
	#round1_inter = copy.deepcopy(round1_result)
	# for debug/info
	time.sleep(0.33);
	print(round1_result)

	return round1_result



# sell IOT for USD
def round2():
	# retrieving results of the first round
	#round1_result = round1_inter

	# TODO:
	# CHECK IF THE ORDER FROM ROUND 1 WAS EXECUTED
	#for order in y.orders():
	#	if round1_result[0] == order or len(round2_result) != 0:
	#		print('dick')
	#		pass
#
	#	else:
	#		print('pussy')
	#		round2()



	# deduct fee manually if not checking balance
	#round2_amount = round1 - (round1 * 0.002)

	# check balance to pass the right amount of coins to sell
	round2_balance_total, round2_balance_available = check_balance('exchange', 'iot')
	round2_amount = round2_balance_available

	# check actual price using list index
	round2_ticker = x.ticker(all_symbols[1])[2]

	# amount, price, order type, market type, symbols
	round2_result = y.order_new(str(round2_amount), str(round2_ticker), 'sell', 'exchange market', 'iotusd')
	#round2_inter = copy.deepcopy(round2_result)
	# for debug/info
	time.sleep(0.33);
	print(round2_result)

	return round2_result



# buy ETH for USD
def round3():
	# retrieving results of the second round
	#round2_result = round2_inter

	# TODO:
	# CHECK IF THE ORDER FROM ROUND 2 WAS EXECUTED
	#for order in y.orders():
	#	if round2_result[0] == order or len(round2_result) != 0:
	#		print('dick')
	#		pass

	#	else:
	#		print('pussy')
	#		round3()


	# minimum amount of ETH to buy
	round3_amount = 0.02
	
	# check the balance after round 2 sell
	round3_total, round3_available = check_balance('exchange', 'usd')

	# amount, price, order type, market type, symbols
	round3_result = y.order_new(str(round3_amount), str(round3_available), 'buy', 'exchange market', 'ethusd')
	round3_inter = copy.deepcopy(round3_result)
	# for debug/info
	print(round3_result)

	return round3_result






#			SIMCRAFT
balance_total, balance_available = check_balance('exchange', 'eth')
print(balance_available)
results = (((balance_available / round1_bid) * round2_ask) / round3_bid)
print(results)




#			GO
# check if it makes sense
if results > balance_available and (results - balance_available) > 0.00075:
	print('\nplace order')

	print('projected profit: {:.8f}'.format(float(results - balance_available)))
	
	round1()
	round2()
	round3()

	new_balance_total, new_balance_available = check_balance('exchange', 'eth')
	print('real profit: {:.8f}'.format(new_balance_available - balance_available))
	#print('diff:', )


	#time.sleep(10)
	#tickerz_raw = x.tickers(symbols)
	#print(tickerz_raw)

else:
	print('\nwait')

	new_balance_total, new_balance_available = check_balance('exchange', 'eth')
	print('{:.8f}'.format(float(results - new_balance_available)))


print('*' * 100)
#print(round1_inter)
#rint(round2_inter)
#print(round3_inter)
