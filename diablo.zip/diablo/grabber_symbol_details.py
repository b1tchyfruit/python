import time, json, uuid
import requests, psycopg2
from bfxi import wrapperi

from psycopg2 import extras

# collecting the data from Bitfinex via API v1

x = wrapperi.Bitfinex()

all_symbols_t = list()
for item in x.symbols_details():
	if 'usd' in item['pair']:
		u = uuid.uuid1()
		t = list()
		t.append(str(u))
		t.append('t' + item['pair'].upper())
		t.append(float(item['minimum_order_size']))
		t.append('now()')
		all_symbols_t.append(tuple(t))

# inserting collected data to the database

# connect to the DB
conn = psycopg2.connect("dbname=inferno user=innerpartycolt")

# open a cursor
cur = conn.cursor()

# drop table if exists
#cur.execute("""
#	drop table if exists symbol_details;
#
#	create table symbol_details (
#		id varchar(36) unique,
#		pair varchar(10),
#		minimum_order_size decimal,
#		last_update timestamp
#	);
#	""")



# remove data older than 3 hours
cur.execute("""
	select * from symbol_details;
	delete from symbol_details
		where last_update < now() - interval '3 hour';

	""")



# pass the data
extras.execute_values(cur,
	"insert into symbol_details (id, pair, minimum_order_size, last_update) values %s",
	all_symbols_t
	)


# lookup changes
print('\ndata preview')
cur.execute("select * from symbol_details;")
for record in cur:
	print(record)

# make the changes to the database persistent
conn.commit()

# inform
print('data commit successful')

# close communication
cur.close()
conn.close()