# grabber symbol details

drop table if exists symbol_details;

create table symbol_details (
	id varchar(36) unique,
	pair varchar(10),
	minimum_order_size decimal,
	last_update timestamp
);





insert into symbol_details (pair, minimum_order_size, last_update)
	values (%s, %s, clock_timestamp())
on conflict (pair)
	do update
		set minimum_order_size = %s,
		last_update = clock_timestamp();



# grabber tickers

drop table if exists tickers;

create table tickers (
	id varchar(36) unique,
	symbol varchar(10),
	daily_change_perc decimal,
	last_price decimal,
	volume decimal,
	high decimal,
	last_update timestamp
);