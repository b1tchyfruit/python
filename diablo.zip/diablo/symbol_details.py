import time, json, uuid, datetime
import requests, psycopg2
from bfxi import wrapperi

from psycopg2 import extras

# collecting the data from Bitfinex via API v1

x = wrapperi.Bitfinex()

time_now = datetime.datetime.now()
#2001-12-23 14:39:53.662522-05

all_symbols = dict()
all_symbols_l = list()
all_symbols_t = list()
for item in x.symbols_details():
	if 'usd' in item['pair']:
		all_symbols.update({'t' + item['pair'].upper(): float(item['minimum_order_size'])})

		# LIST
		x = list()
		x.append('t' + item['pair'].upper())
		x.append(float(item['minimum_order_size']))
		all_symbols_l.append(x)

		#TUPLE
		u = uuid.uuid1()
		t = list()
		t.append(str(u))
		t.append('t' + item['pair'].upper())
		t.append(float(item['minimum_order_size']))
		t.append(time_now)
		all_symbols_t.append(tuple(t))

print('dict')
print({k: v for k, v in all_symbols.items()})

print('\nlist')
print(all_symbols_l)

print('\ntuple')
rows = all_symbols_t
values = ', '.join(map(str, rows))
sql = '{}'.format(values)
print(sql)

# inserting collected data to the database

# connect to the DB
conn = psycopg2.connect("dbname=inferno user=innerpartycolt")

# open a cursor
cur = conn.cursor()

# drop table if exists
#cur.execute("""
#	drop table if exists symbol_details;
#
#	create table symbol_details (
#		id varchar(36) unique,
#		pair varchar(10),
#		minimum_order_size decimal,
#		last_update timestamp
#	);
#	""")


# pass the data
#for item in all_symbols_l:
#	cur.execute("""
#insert into symbol_details (pair, minimum_order_size, last_update)
#	values(%s, %s, transaction_timestamp())
#on conflict (pair)
#	do update
#		set minimum_order_size = %s,
#		last_update = transaction_timestamp();
#		""",
#		
#		#all_symbols_l
#		(item[0], item[1], item[1])
#		)




# remove data older than 2 days
#cur.execute("""
#	select * from symbol_details;
#	delete from symbol_details
#		where last_update < now() interval '2 days';
#
#	""")




# pass the data
extras.execute_values(cur,
	"insert into symbol_details (id, pair, minimum_order_size, last_update) values %s",
	all_symbols_t
	)

#cur.executemany("""
#	insert into symbol_details (id, pair, minimum_order_size, last_update)
#		values %s;
#	""",

#all_symbols_t
#(sql,)
#)


# lookup changes
print('\ndata preview')
cur.execute("select * from symbol_details;")
for record in cur:
	print(record)
#cur.fetchall()

# make the changes to the database persistent
conn.commit()

# inform
print('data commit successful')

# close communication
cur.close()
conn.close()