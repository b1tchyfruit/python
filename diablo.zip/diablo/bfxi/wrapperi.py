import json, base64, hmac, hashlib, time
import requests

base_url = 'https://api.bitfinex.com/v1/'
api_key = '7ANqjm4yFq8cyg07HMaLOewuPiJaX5ZBBKCdxf4LSaj'
api_secret = 'r5qBiuU1iOFyZGtW3Nf3rUfxNa8TvuEE7upTs85faj8'


public = {
	'symbols_details' : 'symbols_details',
}

private = {
	'balances' : 'balances',
	'order_new' : 'order/new',
	'orders' : 'orders',
}

payload = {
	
}

class Bitfinex:

	# PUBLIC

	def symbols_details(self):
		url = base_url + public['symbols_details']
		response = requests.request('GET', url)

		return json.loads(response.text)





	# PRVATE

	def _nonce(self):
		"""
		Returns a nonce
		Used in authentication
		"""
		return str(time.time() * 1000000)

	def _sign_payload(self, payload):
		j = json.dumps(payload)
		data = base64.standard_b64encode(j.encode('utf8'))

		h = hmac.new(api_secret.encode('utf8'), data, hashlib.sha384)
		signature = h.hexdigest()

		return {
			"X-BFX-APIKEY": api_key,
			"X-BFX-SIGNATURE": signature,
			"X-BFX-PAYLOAD": data
			}

	def balances(self):
		url = base_url + private['balances']

		payload = {
			"request": "/v1/balances",
			"nonce": self._nonce()
		}

		signed_payload = self._sign_payload(payload)
		r = requests.post(url, headers=signed_payload, verify=True)
		json_resp = r.json()

		return json_resp



	def order_new(self, amount, price, side, order_type, symbol, exchange='bitfinex'):
		url = base_url + private['order_new']

		payload = {
			'request': '/v1/order/new',
			'nonce': self._nonce(),
			'symbol': symbol,
			'amount': amount,
			'price': price,
			'exchange': exchange,
			'side': side,
			'type': order_type,
		}

		signed_payload = self._sign_payload(payload)
		r = requests.post(url, headers=signed_payload, verify=True)
		json_resp = r.json()

		try:
			success = list()
			x = success.append(json_resp['id'])
			x = success.append(json_resp['symbol'])
			x = success.append(json_resp['price'])
			x = success.append(json_resp['side'])
			x = success.append(json_resp['original_amount'])
			x = success.append(json_resp['remaining_amount'])
			x = success.append(json_resp['executed_amount'])
			x = success.append(json_resp['order_id'])

			return success

		except:
			return json_resp['message']

		return json_resp


	def orders(self):
		url = base_url + private['orders']

		payload = {
			"request": "/v1/orders",
			"nonce": self._nonce()
		}

		signed_payload = self._sign_payload(payload)
		r = requests.post(url, headers=signed_payload, verify=True)
		json_resp = r.json()

		try:
			success = list()
			for item in json_resp:
				y = success.append(item['id'])

			return success

		except:
			return json_resp['message']

		return json_resp
