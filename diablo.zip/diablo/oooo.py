# balance
#print('\nbalance')
#print(round_1_balance)

# first run
#first = balance / ltcbtc_bid
#print('\nfirst run')
#print(first)

# second run
#second = first * ltcusd_ask
#print('\nsecond run')
#print(second)

# third run
#third = second / btcusd_bid
#print('\nthird run')
#print(third)

from bfxi import wrapperi
y = wrapperi.Bitfinex()


for i in y.orders():
    if 7171708433 == i:
        print('dick')

    else:
        print('pussy')