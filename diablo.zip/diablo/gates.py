from bfxi import wrapperi
import requests, json

ignore_symbols = ['yyw']

x = wrapperi.Bitfinex()

oi = list()
all_symbols = list()
for i in x.symbols_details():
	if 'usd' in i['pair']:
		for ignore in ignore_symbols:
			if ignore not in i['pair']:
				oi.append(float(i['minimum_order_size']))
				all_symbols.append('t' + i['pair'].upper()) # all pairs
				
				print(i['pair'], i['minimum_order_size'], i['maximum_order_size'])

#dick = sum(oi) / len(oi)
#print('average minimum:', dick)



base_url = 'https://api.bitfinex.com/v2/'

public = {
	'tickers' : 'tickers?symbols=',
}

symbols = ','.join(all_symbols)
#print(all_symbols)

url = base_url + public['tickers'] + symbols
#print(url)

response = requests.request('GET', url)
for i in json.loads(response.text):
	if 'btcusd'.upper() in i:
		btc_rate = i[1]
		print(btc_rate)

	if (i[8] * float(i[7])) / btc_rate > 1000 and i[6] > 0.1:
		print('symbol: {}, 24h change: {:6.2f}, last price: {:16.8f}, volume: {:9.0f}'.format(i[0], float(i[6]) * 100, float(i[7]), (i[8] * float(i[7])) / btc_rate ))





# select pairs matching change/volume/last_price criteria
# form new table from selected pairs
# track N last rows of each pair
# buy if N last rows show growth in Y parameters
# repeat with other pairs









